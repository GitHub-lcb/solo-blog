title: Java面试资料整理
date: '2019-09-23 22:26:09'
updated: '2019-09-23 22:26:09'
tags: [Java面试项目资源]
permalink: /articles/2019/09/23/1569248769693.html
---
#   github开源项目3个推荐 : 
### 1. https://github.com/CyC2018/CS-Notes
### 2. https://github.com/Snailclimb/JavaGuide
### 3. https://github.com/doocs/advanced-java

#  其他面试资料整理
## 1.  <<Java面试宝典5.0>>
	链接：https://pan.baidu.com/s/1bl7-s3ueG_0VezhMw_XbBQ 
	提取码：og64
## 2. JavaEE项目实战  (博学谷)(账号可分享,有意可联系我)
* 学成在线
* SaaS-HRM
* 好客租房


**仅部分截图:**
![image.png](https://img.hacpai.com/file/2019/09/image-9c729456.png)

![image.png](https://img.hacpai.com/file/2019/09/image-32cda5eb.png)

![image.png](https://img.hacpai.com/file/2019/09/image-d16124bc.png)



## 3. 慕课网项目实战
* [Google面试官亲授-Java面试新手尊享课](https://coding.imooc.com/learn/list/132.html)
* [Spring Boot仿抖音短视频小程序开发 全栈式实战项目](https://coding.imooc.com/learn/list/217.html)
* [2019版 微服务时代Spring Boot企业微信点餐系统](https://coding.imooc.com/learn/list/117.html)
## 4. 芋道源码
地址 : **http://svip.iocoder.cn/index**
账号/密码 : **yudaoyuanma/ydym1024**
