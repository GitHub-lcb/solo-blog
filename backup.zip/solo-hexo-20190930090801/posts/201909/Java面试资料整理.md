title: Java面试资料整理
date: '2019-09-24 13:29:15'
updated: '2019-09-24 13:29:15'
tags: [Java, 面试, 项目]
permalink: /articles/2019/09/24/1569302954793.html
---
![](https://img.hacpai.com/bing/20180124.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

 # 1.github开源推荐
###  https://github.com/CyC2018/CS-Notes
![image.png](https://img.hacpai.com/file/2019/09/image-ec7ed3b1.png)

### https://github.com/Snailclimb/JavaGuide
![image.png](https://img.hacpai.com/file/2019/09/image-1d8c2b0b.png)

### https://github.com/doocs/advanced-java
![image.png](https://img.hacpai.com/file/2019/09/image-6f75640c.png)

# 2.芋道源码
**网址 : http://svip.iocoder.cn
账号/密码 : yudaoyuanma/ydym1024**
![image.png](https://img.hacpai.com/file/2019/09/image-ccb19c8a.png)

# 3.项目推荐
### 3.1 博学谷(已购,有缘人可分享账号)
> 知识涵盖量非常广 , 至少包括3个完整项目

![image.png](https://img.hacpai.com/file/2019/09/image-3e074dbb.png)

### 3.2 慕课网(已购,有缘人可分享账号)
![image.png](https://img.hacpai.com/file/2019/09/image-c937dbfd.png)

**相逢既是有缘,期待共同进步~**
