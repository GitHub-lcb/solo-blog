title: compare make beauty (031 to 040)
date: '2019-10-04 16:08:20'
updated: '2019-10-04 16:10:55'
tags: [Redis, Struts2, Hibernate, Shiro]
permalink: /articles/2019/10/04/1570176500549.html
---
![](https://img.hacpai.com/bing/20190413.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 031.SpringMVC 和 Struts2 的区别？
1、Struts2 是类级别的拦截， 一个类对应一个 request 上下文，SpringMVC 是方法级别的拦截，一个方法对应 一个request上下文，而方法同时又跟一个url对应,所以说从架构本身上SpringMVC就容易实现restful url,而struts2 的架构实现起来要费劲，因为 Struts2 中 Action 的一个方法可以对应一个 url，而其类属性却被所有方法共享，这也 就无法用注解或其他方式标识其所属方法了。
2、由上边原因，SpringMVC 的方法之间基本上独立的，独享 request response 数据，请求数据通过参数获取， 处理结果通过 ModelMap 交回给框架，方法之间不共享变量，而 Struts2 搞的就比较乱，虽然方法之间也是独立的， 但其所有 Action 变量是共享的，这不会影响程序运行，却给我们编码 读程序时带来麻烦，每次来了请求就创建一个 Action，一个 Action 对象对应一个 request 上下文。
3、由于 Struts2 需要针对每个 request 进行封装，把 request，session 等 servlet 生命周期的变量封装成一个一个 Map，供给每个 Action 使用，并保证线程安全，所以在原则上，是比较耗费内存的。
4、 拦截器实现机制上，Struts2 有以自己的 interceptor 机制，SpringMVC 用的是独立的 AOP 方式，这样导致 Struts2 的配置文件量还是比 SpringMVC 大。
5、SpringMVC 的入口是 servlet，而 Struts2 是 filter（这里要指出，filter 和 servlet 是不同的。），这就导致 了二者的机制不同，这里就牵涉到 servlet 和 filter 的区别了。
6、SpringMVC 集成了 Ajax，使用非常方便，只需一个注解@ResponseBody 就可以实现，然后直接返回响应文 本即可，而 Struts2 拦截器集成了 Ajax，在 Action 中处理时一般必须安装插件或者自己写代码集成进去，使用起来也 相对不方便。
7、SpringMVC 验证支持 JSR303，处理起来相对更加灵活方便，而 Struts2 验证比较繁琐，感觉太烦乱。
8、Spring MVC 和 Spring 是无缝的。从这个项目的管理和安全上也比 Struts2 高（当然 Struts2 也可以通过不 同的目录结构和相关配置做到 SpringMVC 一样的效果，但是需要 xml 配置的地方不少）。
9、 设计思想上，Struts2 更加符合 OOP 的编程思想， SpringMVC 就比较谨慎，在 servlet 上扩展。
10、SpringMVC 开发效率和性能高于 Struts2。
11、SpringMVC 可以认为已经 100%零配置。
# 032.Hibernate 和 Mybatis 的区别？
* 两者相同点：
 1）Hibernate 与 MyBatis 都可以是通过 SessionFactoryBuider 由 XML 配置文件生成 SessionFactory，然后由 SessionFactory 生成 Session，最后由 Session 来开启执行事务和 SQL 语句。其中 SessionFactoryBuider， SessionFactory，Session 的生命周期都是差不多的。 
2）Hibernate 和 MyBatis 都支持 JDBC 和 JTA 事务处理。 

* Mybatis 优势： 
1）MyBatis 可以进行更为细致的 SQL 优化，可以减少查询字段。 
2）MyBatis 容易掌握，而 Hibernate 门槛较高。 
* Hibernate 优势：
 1）Hibernate 的 DAO 层开发比 MyBatis 简单，Mybatis 需要维护 SQL 和结果映射。
 2）Hibernate 对对象的维护和缓存要比 MyBatis 好，对增删改查的对象的维护要方便。 
3）Hibernate 数据库移植性很好，MyBatis 的数据库移植性不好，不同的数据库需要写不同 SQL。 
4）Hibernate 有更好的二级缓存机制，可以使用第三方缓存。MyBatis 本身提供的缓存机制不佳。
# 033.Hibernate中get 和 load 的区别？
（1）get 是立即加载，load 是延时加载。 
（2）get 会先查一级缓存，再查二级缓存，然后查数据库;load 会先查一级缓存，如果没有找到，就创建代理对 象，等需要的时候去查询二级缓存和数据库。(这里就体现 load 的延迟加载的特性。) 
（3）get 如果没有找到会返回 null，load 如果没有找到会抛出异常。 
（4）当我们使用 session.load()方法来加载一个对象时，此时并不会发出 sql 语句，当前得到的这个对象其实是 一个代理对象，这个代理对象只保存了实体对象的 id 值，只有当我们要使用这个对象，得到其它属性时，这个时候才 会发出 sql 语句，从数据库中去查询我们的对象；相对于 load 的延迟加载方式，get 就直接的多，当我们使用 session.get()方法来得到一个对象时，不管我们使不使用这个对象，此时都会发出 sql 语句去从数据库中查询出来。
# 034.Spring 的两种代理 JDK 和 CGLIB 的区别 ?
Java 动态代理是利用反射机制生成一个实现代理接口的匿名类，在调用具体方法前调用 InvokeHandler 来处理。 而 cglib 动态代理是利用 asm 开源包，对代理对象类的 class 文件加载进来，通过修改其字节码生成子类来处理。
1、如果目标对象实现了接口，默认情况下会采用 JDK 的动态代理实现 AOP 
2、如果目标对象实现了接口，可以强制使用 CGLIB 实现 AOP 3、如果目标对象没有实现了接口，必须采用 CGLIB 库，spring 会自动在 JDK 动态代理和 CGLIB 之间转换.
# 035.Session 的清理和清空有什么区别？
Session 清理缓存是指按照缓存中对象的状态的变化来同步更新数据库；清空是 Session 的关闭；
# 036.Memcache 与 Redis 的区别都有哪些？
（1）、存储方式不同，Memcache 是把数据全部存在内存中，数据不能超过内存的大小，断电后数据库会挂掉。Redis 有部分存在硬盘上，这样能保证数据的持久性.
（2）、数据支持的类型不同 memcahe 对数据类型支持相对简单，redis 有复杂的数据类型。
（3）、使用底层模型不同 它们之间底层实现方式 以及与客户端之间通信的应用协议不一样。Redis 直接自己 构建了 VM 机制 ，因为一般的系统调用系统函数的话，会浪费一定的时间去移动和请求
（4）、支持的 value 大小不一样 redis 最大可以达到 1GB，而 memcache 只有 1MB.
# 037.Redis中的AOF与RDB的区别？
#### RDB 优缺点

* RDB 会生成多个数据文件，每个数据文件都代表了某一个时刻中 redis 的数据，这种多个数据文件的方式，**非常适合做冷备**，可以将这种完整的数据文件发送到一些远程的安全存储上去，比如说 Amazon 的 S3 云服务上去，在国内可以是阿里云的 ODPS 分布式存储上，以预定好的备份策略来定期备份 redis 中的数据。
    
* RDB 对 redis 对外提供的读写服务，影响非常小，可以让 redis **保持高性能**，因为 redis 主进程只需要 fork 一个子进程，让子进程执行磁盘 IO 操作来进行 RDB 持久化即可。
    
* 相对于 AOF 持久化机制来说，直接基于 RDB 数据文件来重启和恢复 redis 进程，更加快速。
    
* 如果想要在 redis 故障时，尽可能少的丢失数据，那么 RDB 没有 AOF 好。一般来说，RDB 数据快照文件，都是每隔 5 分钟，或者更长时间生成一次，这个时候就得接受一旦 redis 进程宕机，那么会丢失最近 5 分钟的数据。
    
* RDB 每次在 fork 子进程来执行 RDB 快照数据文件生成的时候，如果数据文件特别大，可能会导致对客户端提供的服务暂停数毫秒，或者甚至数秒。
    

#### [](https://github.com/doocs/advanced-java/blob/master/docs/high-concurrency/redis-persistence.md#aof-%E4%BC%98%E7%BC%BA%E7%82%B9)AOF 优缺点

* AOF 可以更好的保护数据不丢失，一般 AOF 会每隔 1 秒，通过一个后台线程执行一次`fsync`操作，最多丢失 1 秒钟的数据。
* AOF 日志文件以 `append-only` 模式写入，所以没有任何磁盘寻址的开销，写入性能非常高，而且文件不容易破损，即使文件尾部破损，也很容易修复。
* AOF 日志文件即使过大的时候，出现后台重写操作，也不会影响客户端的读写。因为在 `rewrite` log 的时候，会对其中的指令进行压缩，创建出一份需要恢复数据的最小日志出来。在创建新日志文件的时候，老的日志文件还是照常写入。当新的 merge 后的日志文件 ready 的时候，再交换新老日志文件即可。
* AOF 日志文件的命令通过非常可读的方式进行记录，这个特性非常**适合做灾难性的误删除的紧急恢复**。比如某人不小心用 `flushall` 命令清空了所有数据，只要这个时候后台 `rewrite` 还没有发生，那么就可以立即拷贝 AOF 文件，将最后一条 `flushall` 命令给删了，然后再将该 `AOF` 文件放回去，就可以通过恢复机制，自动恢复所有数据。
* 对于同一份数据来说，AOF 日志文件通常比 RDB 数据快照文件更大。
* AOF 开启后，支持的写 QPS 会比 RDB 支持的写 QPS 低，因为 AOF 一般会配置成每秒 `fsync` 一次日志文件，当然，每秒一次 `fsync`，性能也还是很高的。（如果实时写入，那么 QPS 会大降，redis 性能会大大降低）
* 以前 AOF 发生过 bug，就是通过 AOF 记录的日志，进行数据恢复的时候，没有恢复一模一样的数据出来。所以说，类似 AOF 这种较为复杂的基于命令日志 / merge / 回放的方式，比基于 RDB 每次持久化一份完整的数据快照文件的方式，更加脆弱一些，容易有 bug。不过 AOF 就是为了避免 rewrite 过程导致的 bug，因此每次 rewrite 并不是基于旧的指令日志进行 merge 的，而是**基于当时内存中的数据进行指令的重新构建**，这样健壮性会好很多。

### [](https://github.com/doocs/advanced-java/blob/master/docs/high-concurrency/redis-persistence.md#rdb-%E5%92%8C-aof-%E5%88%B0%E5%BA%95%E8%AF%A5%E5%A6%82%E4%BD%95%E9%80%89%E6%8B%A9)RDB 和 AOF 到底该如何选择

* 不要仅仅使用 RDB，因为那样会导致你丢失很多数据；
* 也不要仅仅使用 AOF，因为那样有两个问题：第一，你通过 AOF 做冷备，没有 RDB 做冷备来的恢复速度更快；第二，RDB 每次简单粗暴生成数据快照，更加健壮，可以避免 AOF 这种复杂的备份和恢复机制的 bug；
* redis 支持同时开启开启两种持久化方式，我们可以综合使用 AOF 和 RDB 两种持久化机制，用 AOF 来保证数据不丢失，作为数据恢复的第一选择; 用 RDB 来做不同程度的冷备，在 AOF 文件都丢失或损坏不可用的时候，还可以使用 RDB 来进行快速的数据恢复。

# 038.Nginx 和 Apache 各有什么优缺点?
* nginx 相对 apache 的优点 ：
1)轻量级，同样起 web 服务，比 apache 占用更少的内存及资源 
2)抗并发，nginx 处理请求是异步非阻塞的，而 apache 则是阻塞型的，在高并发下 nginx 能保持 
3)低资源低消耗高性能 
4)高度模块化的设计，编写模块相对简单
5)社区活跃，各种高性能模块出品迅速啊
* apache 相对 nginx 的优点:
1)rewrite，比 nginx 的 rewrite 强大 
2)模块超多，基本想到的都可以找到 
3)少 bug，nginx 的 bug 相对较多 
4)超稳定,一般来说，需要性能的 web 服务，用 nginx 。 如果不需要性能只求稳定，那就 apache 吧
# 039.Solr与ES的区别？
　　（1）es基本是开箱即用，非常简单。Solr安装略微复杂一丢丢
　　（2）Solr 利用 Zookeeper 进行分布式管理，而 Elasticsearch 自身带有分布式协调管理功能。
　　（3）Solr 支持更多格式的数据，比如JSON、XML、CSV，而 Elasticsearch 仅支持json文件格式。
　　（4）Solr 官方提供的功能更多，而 Elasticsearch 本身更注重于核心功能，高级功能多有第三方插件提供，例如图形化界面需要kibana友好支撑
　　（5）Solr 查询快，但更新索引时慢（即插入删除慢），用于电商等查询多的应用；
　　　　  ES建立索引快（即查询慢），即实时性查询快，用于facebook新浪等搜索。
　　   　 Solr 是传统搜索应用的有力解决方案，但 Elasticsearch 更适用于新兴的实时搜索应用。
　　（6）Solr比较成熟，有一个更大，更成熟的用户、开发和贡献者社区，而 Elasticsearch相对开发维护者较少，更新太快，学习使用成本较高。
# 040.Shiro与SpringSecurity的区别？
![image.png](https://img.hacpai.com/file/2019/10/image-c8f61a82.png)
* 相同点：
认证功能，授权功能，加密功能，会话管理，缓存支持，rememberMe功能。
* 不同点：
**Spring Security基于Spring开发，项目中如果使用Spring作为基础，配合Spring Security做权限更加方便，而Shiro需要和Spring进行整合开发**
**Spring Security功能比Shiro更加丰富些，例如安全防护**
**Spring Security社区资源比Shiro丰富**
**Shiro的配置和使用比较简单，Spring Security上手复杂**
**Shiro依赖性低，不需要任何框架和容器，可以独立运行，而Spring Security依赖于Spring容器**

